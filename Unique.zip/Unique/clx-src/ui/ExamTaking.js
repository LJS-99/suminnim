/*
 * "제출 버튼" 버튼(vcMsm)에서 click 이벤트 발생 시 호출.
 * 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 */
function onVcMsmClick2(e){
	
	var vcMsm = e.control;
	var submission = app.lookup("msm12");
  	submission.send();
	
}

/*
 * 매트릭스 서브미션에서 submit-success 이벤트 발생 시 호출.
 * 통신이 성공하면 발생합니다.
 */
function onMsm12SubmitSuccess(e){
	var msm12 = e.control;

	var msm1 = app.lookup("msm1");
	var roomSeq = msm1.getValue(0, "roomSeq");
	var roomName = msm1.getValue(0, "roomName");

	app.lookup("output1").value = roomSeq;
	app.lookup("output2").value = roomName;

	console.log("[submit-success] roomSeq =", roomSeq);
	console.log("[submit-success] roomName =", roomName);
}


