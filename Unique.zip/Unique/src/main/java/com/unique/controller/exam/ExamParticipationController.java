package com.unique.controller.exam;

import com.unique.dto.exam.ExamParticipationDTO;
import com.unique.dto.quiz.QuizDTO;
import com.unique.service.exam.ExamParticipationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/exam-participation")
@RequiredArgsConstructor
public class ExamParticipationController {

    private final ExamParticipationService examParticipationService;

    // 시험응시 : 시험방 리스트 클릭 -> 입장
    @PostMapping("/{roomSeq}")
    public Map<String, Object> getExamParticipationDetail(@PathVariable("roomSeq") Long roomSeq) {
        ExamParticipationDTO dto = examParticipationService.getExamParticipationDetail(roomSeq);

        Map<String, Object> result = new HashMap<>();
        result.put("msm1", dto); // 반드시 최상단 키가 msm1

        System.out.println("[ExamParticipation] 응답 데이터: " + result);
        return result;
    }

}