package com.unique.controller.member;

public class MemberAuthController {
}
