package com.unique.config.security;

public class CustomUserDetails {
}
