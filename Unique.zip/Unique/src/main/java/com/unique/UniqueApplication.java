package com.unique;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniqueApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniqueApplication.class, args);
	}

}
