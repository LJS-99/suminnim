package com.unique.dto.member;

import lombok.Data;
@Data
public class FindIdRequestDTO {
    private String name;
    private String email;
}
