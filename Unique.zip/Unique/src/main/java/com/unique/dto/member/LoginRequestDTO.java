package com.unique.dto.member;

import lombok.Data;

@Data
public class LoginRequestDTO {
        private String userId;
        private String password;
}
