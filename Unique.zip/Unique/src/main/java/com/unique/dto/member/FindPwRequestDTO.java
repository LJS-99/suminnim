package com.unique.dto.member;

import lombok.Data;
@Data
public class FindPwRequestDTO {
    private String userId;
    private String email;
}
