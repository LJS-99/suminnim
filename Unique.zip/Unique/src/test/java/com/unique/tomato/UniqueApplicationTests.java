package com.unique.tomato;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
